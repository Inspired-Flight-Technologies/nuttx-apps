#pragma once
#include <uavcan.protocol.GetDataTypeInfo_req.h>
#include <uavcan.protocol.GetDataTypeInfo_res.h>

#define UAVCAN_PROTOCOL_GETDATATYPEINFO_ID 2
#define UAVCAN_PROTOCOL_GETDATATYPEINFO_SIGNATURE (0x1B283338A7BED2D8ULL)
