#pragma once
#include <uavcan.protocol.RestartNode_req.h>
#include <uavcan.protocol.RestartNode_res.h>

#define UAVCAN_PROTOCOL_RESTARTNODE_ID 5
#define UAVCAN_PROTOCOL_RESTARTNODE_SIGNATURE (0x569E05394A3017F0ULL)
