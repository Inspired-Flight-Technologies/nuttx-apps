#pragma once
#include <uavcan.protocol.GetNodeInfo_req.h>
#include <uavcan.protocol.GetNodeInfo_res.h>

#define UAVCAN_PROTOCOL_GETNODEINFO_ID 1
#define UAVCAN_PROTOCOL_GETNODEINFO_SIGNATURE (0xEE468A8121C46A9EULL)
