#pragma once
#include <uavcan.protocol.param.ExecuteOpcode_req.h>
#include <uavcan.protocol.param.ExecuteOpcode_res.h>

#define UAVCAN_PROTOCOL_PARAM_EXECUTEOPCODE_ID 10
#define UAVCAN_PROTOCOL_PARAM_EXECUTEOPCODE_SIGNATURE (0x3B131AC5EB69D2CDULL)
