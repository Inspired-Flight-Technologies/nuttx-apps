#pragma once
#include <uavcan.protocol.GetTransportStats_req.h>
#include <uavcan.protocol.GetTransportStats_res.h>

#define UAVCAN_PROTOCOL_GETTRANSPORTSTATS_ID 4
#define UAVCAN_PROTOCOL_GETTRANSPORTSTATS_SIGNATURE (0xBE6F76A7EC312B04ULL)
